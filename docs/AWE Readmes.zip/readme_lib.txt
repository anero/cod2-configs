Liberation - AWE mod compatible version
Version : 1.7
Author : [HI]DW
Credits : Bullet-Worm (scripting), Bell (AWE mod), Ravir (cvardef function), La Truffe (inclusion in AWE mod, minor changes)
	

See lib.cfg for dvar definitions.


This is an adaptation of the famous MOHAA Breakthrough gametype.
This gametype needs specific maps that provide 2 jails, one for each team.
A lot of maps are being converted to support it. Check http://www.codutility.com is to find LIB compatible maps.
When players die, they respawn in the enemy's jail.
Players can free their team mates by activating a switch near the jail.
A team wins the round when all opponents are in jail.