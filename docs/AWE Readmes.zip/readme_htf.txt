Hold the Flag - AWE mod compatible version
Version : 1.1
Author : La Truffe (latruffe666@hotmail.com)
Credits : Bell (AWE mod, HTF 1.0), Ravir (cvardef function)
	

See htf.cfg for dvar definitions.


New in 1.1 :
- better compatibility with COD2 1.3
- flashing flag on the HUD
- all text is localized
- adjustable individual points for events like : killing regular players, killing the flag carrier, assisting the flag carrier, stealing the flag from the enemy, holding the flag when team scores
- removed dvar scr_htf_removeflagspawns
- force players to spawn away from the flag, at a minimum distance controlled by scr_htf_spawndistance
- in random flag spawns mode, flag recovery also applies when flag has not been stolen, acting as a time-out for stealing the flag
- message indicating when flag is recovered
- default value for scr_htf_flagrecovertime changed to 180 (not disabled by default)
- new value for scr_htf_randomflagspawns for spawning the flag at the farthest position from the majority of players
- more informative serverinfo screen